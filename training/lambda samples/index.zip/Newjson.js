var a=[{"avf":"rr"},{"fr":"gtgt"}];
console.log(a);
